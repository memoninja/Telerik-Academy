﻿// 4. Write a program to print the numbers 1, 101 and 1001.

using System;

class PrintThreeNumbers
{
    static void Main()
    {
        Console.WriteLine("{0}, {1}, {2}", 1, 101, 1001);
    }
}
