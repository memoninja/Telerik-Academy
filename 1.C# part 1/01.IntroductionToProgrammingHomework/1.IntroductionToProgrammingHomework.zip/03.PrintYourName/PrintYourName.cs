﻿// 3. Modify the application to print your name.

using System;

class PrintYourName
{
    static void Main()
    {
        Console.WriteLine("My name is: name to be printed...");
    }
}
