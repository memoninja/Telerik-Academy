﻿// 6. Create console application that prints your first and last name.

using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("My first name is: {0} \nMy second name is: {1}", "First name", "Second name");
    }
}
