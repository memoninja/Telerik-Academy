﻿// 7. Create a console application that prints the current date and time.

using System;

class PrintDateAndTime
{
    static void Main()
    {
        Console.WriteLine("Current date and time is: {0}", DateTime.Now);
    }
}